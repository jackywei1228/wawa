<?php return array (
  'DEFAULT_MODULE' => 'Wap',
  'DB_HOST' => '127.0.0.1',
  'DB_NAME' => 'haokuai',
  'DB_USER' => 'root',
  'DB_PWD' => 'root',
  'DB_PORT' => '3306',
  'DB_PREFIX' => 'haokuai_',
  'URL_MODEL' => 0,
  'TMPL_FILE_DEPR' => '_',
  'WX_TOKEN' => 'haokuai',
  'DB_TYPE' => 'mysql',
  'TMPL_ACTION_SUCCESS' => './Project//Common/View/success.html',
  'TMPL_ACTION_ERROR' => './Project//Common/View/error.html',
  'DEFAULT_CONTROLLER'    =>  'Jiawawa', // 默认控制器名称
  'DEFAULT_ACTION'        =>  'action', // 默认操作名称
);