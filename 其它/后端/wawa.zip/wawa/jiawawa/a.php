<?php
	$data = ['m'=>1000];
	echo json_encode($data);
?>