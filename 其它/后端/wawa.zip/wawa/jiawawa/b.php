<?php
	$data = ['res'=>2,'pa'=>100,'pc'=>10];
	echo json_encode($data);
?>