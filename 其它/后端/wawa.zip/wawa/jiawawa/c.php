<?php

	$data =[10];
	echo json_encode($data);
?>