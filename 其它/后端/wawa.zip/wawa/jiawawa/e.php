<?php
	$data = ["r"=>10];
	echo json_encode($data);
?>